package com.example.bcS3;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.client.builder.AwsClientBuilder.EndpointConfiguration;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.PutObjectResult;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectInputStream;
import com.amazonaws.util.IOUtils;

@Service
public class S3Service implements S3ServiceImpl {
	@Value("${access-key}")
	private String accessKey;

	@Value("${secret-key}")
	private String secretKey;

	@Value("${region}")
	private String region;

	String bucketName = "khadija";

	AmazonS3 s3;

	@PostConstruct

	public void initailisation() {
		AWSCredentials credentials = new BasicAWSCredentials(accessKey, secretKey);
		s3 = AmazonS3ClientBuilder
				.standard()
				// endpoint for EB4
				.withEndpointConfiguration(new EndpointConfiguration("https://storage-eb4.cegedim.cloud", null))
				.withCredentials(new AWSStaticCredentialsProvider(credentials))
				// Set path style to true
				.withPathStyleAccessEnabled(true)
				.build();

		if (!s3.doesBucketExist(bucketName)) {
			s3.createBucket(bucketName);
		}

	}

	@Override
	public String saveFile(MultipartFile file) {

		String originalFilename = file.getOriginalFilename();

		try {
			File file1 = convertMultiPartToFile(file);
			PutObjectResult putObjectResult = s3.putObject(bucketName, originalFilename, file1);
			return putObjectResult.getContentMd5();
		} catch (IOException e) {
			throw new RuntimeException(e);
		}

	}

	@Override
	public byte[] downloadFile(String filename) {
		S3Object object = s3.getObject(bucketName, filename);
		S3ObjectInputStream objectContent = object.getObjectContent();
		try {
			return IOUtils.toByteArray(objectContent);
		} catch (IOException e) {
			throw new RuntimeException(e);

		}

	}

	@Override
	public String deleteFile(String filename) {
		s3.deleteObject(bucketName, filename);
		return "file deleted";
	}

	private File convertMultiPartToFile(MultipartFile file) throws IOException {
		File convFile = new File(file.getOriginalFilename());
		FileOutputStream fos = new FileOutputStream(convFile);
		fos.write(file.getBytes());
		fos.close();
		return convFile;
	}
}
