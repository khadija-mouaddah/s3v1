package com.example.bcS3;

import org.springframework.web.multipart.MultipartFile;

public interface S3ServiceImpl {
	String saveFile(MultipartFile file);

	byte[] downloadFile(String filename);

	String deleteFile(String filename);
}
