package com.example.bcS3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BcS3Application {

	public static void main(String[] args) {
		SpringApplication.run(BcS3Application.class, args);
	}

}
